﻿$(document).ready(function () {
    $('.btnAddCanonicalUrl').click(function (e) {

        $('#txtRequestUrl').val('');
        $('#resultUrlReqVal').css('display', 'none');
        $('div.editPop').modal({
            onClose : function() {
                window.location.reload(true);
            }
        });
        $('#simplemodal-container').appendTo($('form:first'));
        return false;
    });
});